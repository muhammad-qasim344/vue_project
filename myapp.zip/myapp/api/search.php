<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$pdo = new PDO("mysql:host=localhost;dbname=test", "root", "");

// Search Query
$q = isset($_GET['q']) ? $_GET['q'] : '';

if ($q) {
    $stmt = $pdo->prepare("SELECT id, name, price FROM products WHERE name LIKE ?");
    $stmt->execute(["%$q%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($results);
} else {
    echo json_encode([]);
}
